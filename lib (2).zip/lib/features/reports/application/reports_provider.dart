import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../personnel/application/personnel_provider.dart';
import '../../personnel/domain/models/personnel.dart';
import '../../personnel/domain/services/personnel_status_resolver.dart';
import '../../leave/application/leave_provider.dart';
import '../../leave/domain/models/leave.dart';
import '../domain/models/report_statistics.dart';

final personnelReportStatisticsProvider =
    Provider<AsyncValue<PersonnelReportStatistics>>((ref) {
      final personnelAsync = ref.watch(personnelListProvider);
      final leaveAsync = ref.watch(leaveControllerProvider);

      if (personnelAsync.isLoading || leaveAsync.isLoading) {
        return const AsyncLoading();
      }

      if (personnelAsync.hasError) {
        return AsyncError(personnelAsync.error!, personnelAsync.stackTrace!);
      }

      if (leaveAsync.hasError) {
        return AsyncError(leaveAsync.error!, leaveAsync.stackTrace!);
      }

      final personnel = personnelAsync.value!;
      final leaves = leaveAsync.value!;

      final now = DateTime.now();

      final statusList = personnel.map(
        (person) => PersonnelStatusResolver.resolve(
          personnel: person,
          leaves: leaves,
          date: now,
        ),
      );

      final statuses = statusList.toList();

      final workScheduleDistribution = <String, int>{};
      final departmentDistribution = <String, int>{};
      final branchDistribution = <String, int>{};
      final rankDistribution = <String, int>{};

      for (final person in personnel) {
        // ------------------------------------------------------------
        // ÇALIŞMA DÜZENİ
        // ------------------------------------------------------------

        final scheduleLabel = person.workSchedule?.label ?? 'Belirtilmemiş';

        workScheduleDistribution[scheduleLabel] =
            (workScheduleDistribution[scheduleLabel] ?? 0) + 1;

        // ------------------------------------------------------------
        // ŞUBE
        // ------------------------------------------------------------

        departmentDistribution[person.department] =
            (departmentDistribution[person.department] ?? 0) + 1;

        // ------------------------------------------------------------
        // BÜRO
        // ------------------------------------------------------------

        branchDistribution[person.branch] =
            (branchDistribution[person.branch] ?? 0) + 1;

        // ------------------------------------------------------------
        // RÜTBE
        // ------------------------------------------------------------

        rankDistribution[person.rank] =
            (rankDistribution[person.rank] ?? 0) + 1;
      }

      return AsyncData(
        PersonnelReportStatistics(
          totalPersonnel: personnel.length,

          dutyPersonnel: statuses
              .where((status) => status == PersonnelStatus.duty)
              .length,

          restingPersonnel: statuses
              .where((status) => status == PersonnelStatus.resting)
              .length,

          leavePersonnel: statuses
              .where((status) => status == PersonnelStatus.leave)
              .length,

          sickReportPersonnel: statuses
              .where((status) => status == PersonnelStatus.sickReport)
              .length,

          workScheduleDistribution: workScheduleDistribution,
          departmentDistribution: departmentDistribution,
          branchDistribution: branchDistribution,
          rankDistribution: rankDistribution,
        ),
      );
    });

final leaveReportStatisticsProvider =
    Provider<AsyncValue<LeaveReportStatistics>>((ref) {
      final leaveAsync = ref.watch(leaveControllerProvider);

      if (leaveAsync.isLoading) {
        return const AsyncLoading();
      }

      if (leaveAsync.hasError) {
        return AsyncError(leaveAsync.error!, leaveAsync.stackTrace!);
      }

      final leaves = leaveAsync.value!;

      var totalLeaveCount = 0;
      var totalLeaveDays = 0;

      var annualLeaveCount = 0;
      var excuseLeaveCount = 0;
      var reportCount = 0;

      var annualLeaveDays = 0;
      var excuseLeaveDays = 0;
      var reportDays = 0;

      final personnelLeaveDays = <String, int>{};

      for (final leave in leaves) {
        final days = leave.dayCount;

        totalLeaveCount++;
        totalLeaveDays += days;

        switch (leave.type) {
          case LeaveType.annual:
            annualLeaveCount++;
            annualLeaveDays += days;
            break;

          case LeaveType.excuse:
            excuseLeaveCount++;
            excuseLeaveDays += days;
            break;

          case LeaveType.report:
            reportCount++;
            reportDays += days;
            break;
        }

        personnelLeaveDays[leave.personnelId] =
            (personnelLeaveDays[leave.personnelId] ?? 0) + days;
      }

      return AsyncData(
        LeaveReportStatistics(
          totalLeaveCount: totalLeaveCount,
          totalLeaveDays: totalLeaveDays,
          annualLeaveCount: annualLeaveCount,
          excuseLeaveCount: excuseLeaveCount,
          reportCount: reportCount,
          annualLeaveDays: annualLeaveDays,
          excuseLeaveDays: excuseLeaveDays,
          reportDays: reportDays,
          personnelLeaveDays: personnelLeaveDays,
        ),
      );
    });
