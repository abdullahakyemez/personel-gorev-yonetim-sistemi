import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:personel_gorev_yonetim_sistemi/core/widgets/page_header.dart';
import 'package:personel_gorev_yonetim_sistemi/core/widgets/cards/pgys_card.dart';
import 'package:personel_gorev_yonetim_sistemi/features/reports/domain/models/report_statistics.dart';

import '../../application/reports_provider.dart';

class ReportsPage extends ConsumerWidget {
  const ReportsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final personnelReportAsync = ref.watch(personnelReportStatisticsProvider);

    final leaveReportAsync = ref.watch(leaveReportStatisticsProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PageHeader(
            title: 'Raporlar',
            subtitle: 'Personel, izin, görev ve performans raporları',
          ),

          const SizedBox(height: 24),

          personnelReportAsync.when(
            loading: () => const Center(
              child: Padding(
                padding: EdgeInsets.all(48),
                child: CircularProgressIndicator(),
              ),
            ),

            error: (error, stackTrace) => PGYSCard(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Row(
                  children: [
                    Icon(
                      Icons.error_outline,
                      color: Theme.of(context).colorScheme.error,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text('Personel raporu oluşturulamadı.\n$error'),
                    ),
                  ],
                ),
              ),
            ),

            data: (report) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _PersonnelReports(report: report),

                const SizedBox(height: 32),

                leaveReportAsync.when(
                  loading: () =>
                      const Center(child: CircularProgressIndicator()),
                  error: (error, stackTrace) =>
                      Text('İzin raporu oluşturulamadı: $error'),
                  data: (leaveReport) => _LeaveReports(report: leaveReport),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PersonnelReports extends StatelessWidget {
  final PersonnelReportStatistics report;

  const _PersonnelReports({required this.report});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '1. Personel Raporları',
          style: Theme.of(context).textTheme.headlineSmall,
        ),

        const SizedBox(height: 16),

        _buildStatusCards(context),

        const SizedBox(height: 24),

        _buildDistributionCard(
          context,
          title: 'Çalışma Düzeni Dağılımı',
          icon: Icons.schedule_outlined,
          data: report.workScheduleDistribution,
        ),

        const SizedBox(height: 16),

        _buildDistributionCard(
          context,
          title: 'Büro Dağılımı',
          icon: Icons.business_outlined,
          data: report.branchDistribution,
        ),

        const SizedBox(height: 16),

        _buildDistributionCard(
          context,
          title: 'Rütbe Dağılımı',
          icon: Icons.military_tech_outlined,
          data: report.rankDistribution,
        ),
      ],
    );
  }

  Widget _buildStatusCards(BuildContext context) {
    return GridView.count(
      crossAxisCount: 5,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.8,
      children: [
        _StatCard(
          title: 'Toplam Personel',
          value: report.totalPersonnel,
          icon: Icons.people_alt_outlined,
        ),
        _StatCard(
          title: 'Görevde',
          value: report.dutyPersonnel,
          icon: Icons.work_outline,
        ),
        _StatCard(
          title: 'İstirahatli',
          value: report.restingPersonnel,
          icon: Icons.hotel_outlined,
        ),
        _StatCard(
          title: 'İzinli',
          value: report.leavePersonnel,
          icon: Icons.beach_access_outlined,
        ),
        _StatCard(
          title: 'Raporlu',
          value: report.sickReportPersonnel,
          icon: Icons.medical_services_outlined,
        ),
      ],
    );
  }

  Widget _buildDistributionCard(
    BuildContext context, {
    required String title,
    required IconData icon,
    required Map<String, int> data,
  }) {
    return PGYSCard(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                Text(title, style: Theme.of(context).textTheme.titleMedium),
              ],
            ),

            const SizedBox(height: 16),

            if (data.isEmpty)
              const Text('Veri bulunmuyor.')
            else
              ...data.entries.map(
                (entry) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(
                    children: [
                      Expanded(child: Text(entry.key)),
                      Text(
                        '${entry.value}',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _LeaveReports extends StatelessWidget {
  final LeaveReportStatistics report;

  const _LeaveReports({required this.report});

  @override
  Widget build(BuildContext context) {
    final sortedPersonnel = report.personnelLeaveDays.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '2. İzin ve Rapor Raporları',
          style: Theme.of(context).textTheme.headlineSmall,
        ),

        const SizedBox(height: 16),

        GridView.count(
          crossAxisCount: 4,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.8,
          children: [
            _StatCard(
              title: 'Toplam Kayıt',
              value: report.totalLeaveCount,
              icon: Icons.event_note_outlined,
            ),
            _StatCard(
              title: 'Toplam Gün',
              value: report.totalLeaveDays,
              icon: Icons.date_range_outlined,
            ),
            _StatCard(
              title: 'Yıllık İzin',
              value: report.annualLeaveDays,
              icon: Icons.beach_access_outlined,
            ),
            _StatCard(
              title: 'Mazeret İzni',
              value: report.excuseLeaveDays,
              icon: Icons.event_busy_outlined,
            ),
          ],
        ),

        const SizedBox(height: 12),

        Row(
          children: [
            Expanded(
              child: _StatCard(
                title: 'Rapor',
                value: report.reportDays,
                icon: Icons.medical_services_outlined,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _StatCard(
                title: 'İzin + Rapor Kaydı',
                value: report.totalLeaveCount,
                icon: Icons.assignment_outlined,
              ),
            ),
          ],
        ),

        const SizedBox(height: 24),

        PGYSCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.people_outline,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'En Fazla İzin / Rapor Kullanan Personeller',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                if (sortedPersonnel.isEmpty)
                  const Text('Henüz izin veya rapor kaydı bulunmuyor.')
                else
                  ...sortedPersonnel
                      .take(10)
                      .map(
                        (entry) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Row(
                            children: [
                              Expanded(child: Text('Sicil: ${entry.key}')),
                              Text(
                                '${entry.value} gün',
                                style: Theme.of(context).textTheme.titleSmall
                                    ?.copyWith(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final int value;
  final IconData icon;

  const _StatCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return PGYSCard(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, size: 28, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$value',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
